// npm install express
// npm install body-parser
// npm install fs
// npm install sync-mysql
// npm install express-session
// si sale un error de authentication, tiene que execute estos queries in mysql workbench en su bd, porque ese module 'sync-mysql'
// no esta actualizado al encrypcion mas moderno que tiene mysql server 8:
// ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '123456789';
// flush privileges;


var express = require('express');
var bodyParser = require('body-parser');
var fs = require('fs');
var mysql = require('sync-mysql');
var session = require('express-session');

//definimos un connection para usar luego
var connection = new mysql({
host: 'localhost',
user: 'root',
password: '123456789',
database: 'appmetas'
});


var app = express();

app.use(session({
secret: 'shhhhhh',
resave: true,
saveUninitialized: true,
cookie: { }
}));

app.use(bodyParser.urlencoded({
extended: false
}));

// tiene que poner el listen antes de las funciones GET y POST
app.listen(8080, function() {
console.log('Servidor corriendo en puerta 8080');
})

//***********************************************************************************
// aqui son nuestras functions 'GET', un GET significa simplemente 'ir' en un browser
//***********************************************************************************


// aqui es cuando ellos viene con simplemente http://localhost:8080/ vamos a devolver 'index.html' como nuesta página de bienvenido
app.get('/', function(req, res) {
res.sendFile('index.html', { root: __dirname }) // {root: __dirname} significa el mismo carpeta donde esta app.js
});


// cuando el usuario quiere ir a la ruta 'login', (osea http://localhost:8080/login) vamos a devolver la página llamada login.html
app.get('/login', function(req, res) {
res.sendFile('login.html', { root: __dirname})
});

app.get('/Crearusuario', function(req, res) {
res.sendFile('Crearusuario.html', { root: __dirname})
});


// cuando uno va al link 'logout', vamos a remover el usuario de la session, asi los 'anadirMeta' y 'deleteMeta' van a saber
//que no hacer nada por seguridad
// tenga en cuenta que, en 'intentaHacerLogin', ahora estamos guardando el usuario en el browser session (vea intentaHacerLogin)
app.get('/logout', function(req, res) {
req.session.usuario = null; //borrar el usuario en session (si existe)
res.sendFile('login.html', { root: __dirname }) //y regresa a la página de login
});



app.get('/deleteMeta', function(req, res) {
//captura los datos del query string. Observe que el query string, se accesa con req.query, mientras en 'post', usamos req.body
var pMetaId = req.query.id;

//captura el usuario, que antes, guardemos en el session
var usuarioEncontrado = req.session.usuario;

//verifica que de verdad *hay* un usuario en la session, osea, no es un 'hack', ni que el usuario ha hecho 'logout' todavia
if(usuarioEncontrado == undefined){
muestraLoginError("Session perdida. Login de nuevo.", res);
}else{
//delete la meta con el 'id' en el querystring
deleteMetaPorMetaId(pMetaId, usuarioEncontrado);
//y muestra nuestra página de metas
muestraPaginaDeMetas(usuarioEncontrado, res);
}
});

//*************************************************************************************************************
// aqui son nuestra 'POST' functions para cuando el usuario esta mandando data al application (de un FORM)
//*************************************************************************************************************

// en el pagina login.html, hay un FORM que intenta mandar un 'usuario' y un 'clave' al action 'intentaHacerLogin'
// vamos hacer un logica de que puede pasar cuando escuchamos esta intento
app.post('/intentaHacerLogin', function(req, res) {
//captura los datos del form post
var pUsuario = req.body.usuario;
var pClave = req.body.clave;

//buscar en el BD los usuarios que coincide con el usuario y clave del form post
var arrayDeUsuarios = getUsuariosPorUsuarioYClave(pUsuario, pClave);

//si los resultados son cero resultados.... osea, no encontre ni un usuario con este usuario y clave...
if (arrayDeUsuarios.length < 1) {
muestraLoginError("Login Invalido", res);//Llamada a la fn de la línea 230
} else { //pues, sabemos que hicimos un login exitoso, osea, que encontramos un usuario
var usuarioEncontrado = arrayDeUsuarios[0]; //vamos assignar el primer registro del array a un nombre mas claro 'usuarioEncontrado'

//*********** Vamos a guradar elobject 'usuario' en el memoria del browser, osea, el 'session', para que luego,
// cuando estamos haciendo 'añadir' y 'delete' y todo que deben tener un usuario autenticado, podemos buscar en el Session
// para asegurar que el usuario todavia esta logged in.
req.session.usuario = usuarioEncontrado;

// y muestra la lista de metas
muestraPaginaDeMetas(usuarioEncontrado, res);
}
}); //fin de app.post ( 'intentaHacerLogin' )

// esto es para hacer un 'insert' de nuestra meta en el bd, y luego, refrescar la página con la lista actualizada
app.post('/anadirMeta', function(req, res) {
//captura los datos del form post
var pMetaNueva = req.body.metaNueva;

//verifica que verdad *hay* un usuario en el session, osea, no es un 'hack', ni que el usuario hizo 'logout' todavia
var usuarioEncontrado = req.session.usuario;

//si perdimos el session, osea, si el usuario no esta logged, devuelve un error
if(usuarioEncontrado == undefined){
muestraLoginError("Session perdido. Login de nuevo.", res);// llamada a la fn de la línea 244
}else{
//insert una meta nueva en la table de metas, con el id del usuario
insertMetaNuevaEnDB(pMetaNueva, usuarioEncontrado);// Llamada a la fn de la línea 203
//y muestra nuestra página de metas
muestraPaginaDeMetas(usuarioEncontrado, res);//Llamada a la fn de la página 252
}

}); //fin de app.post ( 'anadirMeta' )

//CREAR USUARIO NUEVO


app.post('/registroUsuario', function(req, res) {

var pUsuarionuevo= req.body.usuario1;
var pClavenuevo= req.body.clave1;
var pNombrenuevo= req.body.nombre1;
var pCorreonuevo= req.body.correo1;

insertusuarionuevoEnDB(pUsuarionuevo, pClavenuevo, pNombrenuevo, pCorreonuevo);

res.sendFile('Crearusuario.html', { root: __dirname})



});


//****************************************************************************************
// aquí manejando los HTTP errores que ocurren si los user intentan hacer cosas raras...
//****************************************************************************************

// 404 es el codigo de http que significa 'not found' (no encontrado). Aquí definimos lo que debe pasar cuando
// el usuario intenta poner una ruta que no existe, como http://localhost:8080/blabladikluweroiu simplemente devolver nuestro index.html
app.use(function(req, res) {
res.status(404).sendFile('index.html', {
root: __dirname
});
});

//*************************************************************************************************************
// Aquí están nuestras functions personalizadas para ayudarnos con mysql y otro procesos comunes
//*************************************************************************************************************

//vamos hacer un funcion, que devuelva un array de usuarios que tienen un usuario y clave específico ... o un array vacio si no encontra ningun usuario
function getUsuariosPorUsuarioYClave(argUsuario, argClave) {
var results = []; // <-- un array vacio

try {
results = connection.query('SELECT * FROM appmetas.usuarios WHERE usuario = ? AND clave = ?', [argUsuario, argClave]);
} catch (error) {
console.log("Error: " + error.message); //<-- aqui vamos imprimir el mensaje de error en la console (solo si hay un error)
}

return results; //<--siempre devolver un array, aunque tamano cero, o con resultados
}


//y vamos a hacer un función que devuelva todas las metas que pertenecen a un sólo idusuario
function getMetasPorIdUsuario(argIdUsuario) {
var results = [];

try {
results = connection.query('SELECT * FROM appmetas.metas WHERE idusuario = ?', [argIdUsuario]);
} catch (error) {
console.log("Error: " + error.message);
}

return results; // <- este es nuestro 'array' las metas, aunque puede ser cero o muchos registro encontrados
}


//Fn para insertar una meta en la BD
function insertMetaNuevaEnDB(argMetaNueva, argUsuario) {

//vamos a preparar una fecha para el campo 'fechaInicio' - vamos a decir hoy.
var hoyDate = new Date(); // esto inicializa en el día y hora actual

var yyyy = hoyDate.getFullYear(); // sale 4 digitos del yyyy

var mm = hoyDate.getMonth() + 1; //esto es xq los meses en js son 0 a 11
if(mm < 10) mm = "0" + mm; // para formatear como 2 digitos en caso menos de 10

var dd = hoyDate.getDate();
if(dd < 10) dd = "0" + dd; // para formatear como 2 digitos en caso menos de 10

var fechaInicio = yyyy + "-" + mm + "-" + dd; // esto es el formato que quiere mysql, que podemos pasar al INSERT


try {
connection.query('INSERT INTO appmetas.metas SET meta = ?, idusuario = ?, fechaInicio = ?', [argMetaNueva, argUsuario.id, fechaInicio]);
} catch (error) {
console.log("Error: " + error.message);
}

}

//FN PARA INSERTAR USUARIO NUEVO
function insertusuarionuevoEnDB (argUsuarioNuevo, argClaveNuevo, argNombreNuevo, argCorreoNuevo, ){
	try {
connection.query('INSERT INTO appmetas.usuarios SET usuario = ?, clave = ?, nombre = ?, correo = ?', [argUsuarioNuevo, argClaveNuevo, argNombreNuevo, argCorreoNuevo]);
} catch (error) {
console.log("Error: " + error.message);
}
}


//Fn para borrar una meta
function deleteMetaPorMetaId(argMetaId, argUsuario) {

try {
connection.query('DELETE FROM appmetas.metas WHERE id = ? AND idusuario = ?', [argMetaId, argUsuario.id]);
} catch (error) {
console.log("Error: " + error.message);
}

}


//*************************************************************************************************************
// y aquí vamos a hacer unas funciones de utilidad, para muestra nuestras páginas comunes con data
//*************************************************************************************************************

//devolvemos la página de login con un error
function muestraLoginError(argError, res){
var fileContents = fs.readFileSync(__dirname + "\\login.html").toString(); //abrir la página
fileContents = fileContents.replace("<!--error-->", "<div style='color: red;'>"+argError+"</div>"); //inserta el error en la página
res.send(fileContents); //mandar la página al browser
}


//devolvemos la página de metas, con las metas y nombre del usuario
function muestraPaginaDeMetas(argUsuario, res){
var fileContents = fs.readFileSync(__dirname + "\\listademetas.html").toString(); //abrir la pagina
fileContents = fileContents.replace("<!--nombre-->", argUsuario.nombre); //inserta el nombre del usuario
fileContents = fileContents.replace("<!--idusuario-->", argUsuario.id); //inserta el id del usuario

//busca las metas y las formatea en un 'ordered list'
var arrayDeMetas = getMetasPorIdUsuario(argUsuario.id);
var laLista = "<ol id='sortable'>";
for (var i = 0; i < arrayDeMetas.length; i++) {
var id = arrayDeMetas[i].id;
// Observe que aquí, estamos poniendo un 'link' alrededor nuestra meta, que cuando el usuario haga un 'click' en la meta
// este click genera un 'get' a /deleteMeta con un query string de id=[meta id], y procesamos este 'get' arriba
// en app.get(/deleteMeta) muy arriba en la línea 74
laLista = laLista + "<li><a href='/deleteMeta?id="+id+"'>" + arrayDeMetas[i].meta + "</a></li>";
}
laLista = laLista + "</ol>";

fileContents = fileContents.replace("<!--laLista-->", laLista); //inserta las metas en la página
res.send(fileContents); //mandar la pagina al browser
}