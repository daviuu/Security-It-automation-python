-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema Ventas
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema Ventas
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Ventas` DEFAULT CHARACTER SET utf8 ;
USE `Ventas` ;

-- -----------------------------------------------------
-- Table `Ventas`.`Cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Ventas`.`Cliente` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `Cedula` VARCHAR(45) NULL,
  `Nombres` VARCHAR(45) NULL,
  `Apellidos` VARCHAR(45) NULL,
  PRIMARY KEY (`Id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Ventas`.`Factura`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Ventas`.`Factura` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `Iva` DOUBLE NULL,
  `Subtotal` DOUBLE NULL,
  `Total` DOUBLE NULL,
  `Cliente_Id` INT NOT NULL,
  PRIMARY KEY (`Id`),
  INDEX `fk_Factura_Cliente1_idx` (`Cliente_Id` ASC) VISIBLE,
  CONSTRAINT `fk_Factura_Cliente1`
    FOREIGN KEY (`Cliente_Id`)
    REFERENCES `Ventas`.`Cliente` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Ventas`.`Detalle`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `Ventas`.`Detalle` (
  `Id` INT NOT NULL AUTO_INCREMENT,
  `Cantidad` VARCHAR(45) NULL,
  `Total` DOUBLE NULL,
  `Factura_Id` INT NOT NULL,
  PRIMARY KEY (`Id`),
  INDEX `fk_Detalle_Factura_idx` (`Factura_Id` ASC) VISIBLE,
  CONSTRAINT `fk_Detalle_Factura`
    FOREIGN KEY (`Factura_Id`)
    REFERENCES `Ventas`.`Factura` (`Id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
